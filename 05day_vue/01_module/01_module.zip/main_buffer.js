<!-- buffer存放二进制数据的缓存区 -->
<!-- 仅支持 7 位 ASCII 数据 -->
const buf = Buffer.from('runoob', 'ascii');
<!-- hex - 将每个字节编码为两个十六进制字符。 -->
console.log(buf.toString('hex'));
<!-- base64编码 -->
console.log(buf.toString('base64'));

// 创建一个长度为 10、且用 0 填充的 Buffer。
const buf1 = Buffer.alloc(10);

// 创建一个长度为 10、且用 0x1 填充的 Buffer。 
const buf2 = Buffer.alloc(10, 1);

// 创建一个长度为 10、且未初始化的 Buffer。
// 这个方法比调用 Buffer.alloc() 更快，
// 但返回的 Buffer 实例可能包含旧数据，
// 因此需要使用 fill() 或 write() 重写。
const buf3 = Buffer.allocUnsafe(10);

// 创建一个包含 [0x1, 0x2, 0x3] 的 Buffer。
const buf4 = Buffer.from([1, 2, 3]);

// 创建一个包含 UTF-8 字节 [0x74, 0xc3, 0xa9, 0x73, 0x74] 的 Buffer。
const buf5 = Buffer.from('tést');

// 创建一个包含 Latin-1 字节 [0x74, 0xe9, 0x73, 0x74] 的 Buffer。
const buf6 = Buffer.from('tést', 'latin1');
<!-- AAAAAAAAAAAAAA== -->
console.log(buf1.toString('base64'));

<!-- 写入node缓冲区的语法 -->
<!-- buf.write(string[, offset[, length]][, encoding]);写入缓冲区的字符串;缓冲区开始写入的索引值;写入的字节数,使用的编码  -->
<!-- buf.toString([encoding[, start[, end]]])使用的编码;开始读取的索引位置;结束位置 -->
const buf_ = Buffer.alloc(26);
for (var i = 0 ; i < 26 ; i++) {
  buf_[i] = i + 97;
}
console.log( buf_.toString('utf8',0,5));    // 输出: abcde
<!-- 字符串化一个buffer实例 -->
const bufJson = Buffer.from([0x1, 0x2, 0x3, 0x4, 0x5]);
const json = bufJson.toJSON();
console.log(json);//{ type: 'Buffer', data: [ 1, 2, 3, 4, 5 ] }
<!-- 缓冲区合并 -->
<!-- Buffer.concat(list[, totalLength]);用于合并的buffer对象数组；合并后的buffer对象总长度 -->
var buffer11 = Buffer.from(('菜鸟教程'));
var buffer21 = Buffer.from(('www.runoob.com'));
var buffer31 = Buffer.concat([buffer11,buffer21]);
console.log("buffer3 内容: " + buffer31.toString());
<!-- 缓冲区比较 -->
var buffer1c = Buffer.from('ABC');
var buffer2c = Buffer.from('ABCD');
var result = buffer1c.compare(buffer2c);
if(result < 0) {
   console.log(buffer1c + " 在 " + buffer2c + "之前");
}else if(result == 0){
   console.log(buffer1c + " 与 " + buffer2c + "相同");
}else {
   console.log(buffer1c + " 在 " + buffer2c + "之后");
}
<!-- 缓冲区拷贝 -->
<!-- buf.copy(targetBuffer[, targetStart[, sourceStart[, sourceEnd]]]) -->
<!-- buf.slice([start[, end]]) -->
var buf1 = Buffer.from('abcdefghijkl');
var buf2 = Buffer.from('RUNOOB');
//将 buf2 插入到 buf1 指定位置上
buf2.copy(buf1, 2);
console.log(buf1.toString());

