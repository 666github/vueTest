
<!--阻塞代码实例  -->
<!-- var fs = require("fs");
var data = fs.readFileSync('input.txt');
console.log(data.toString());
console.log("程序执行结束，阻塞!"); -->
<!-- 运行时不能有注释代码，系统会识别 -->
<!-- 非阻塞代码实例 -->
var fs = require("fs");
fs.readFile('input.txt', function (err, data) {
    if (err) return console.error(err);
    console.log(data.toString());
});
console.log("程序执行结束，非阻塞!");
<!-- Node.js 基本上所有的事件机制都是用设计模式中观察者模式实现。 -->
