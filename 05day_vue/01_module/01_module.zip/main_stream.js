<!-- 从流中读取数据 -->
var fs=require('fs');
var data='';
<!-- 创建可读流 -->
var readerStream=fs.createReadStream('input.txt');
<!-- 设置编码为utf-8 -->
readerStream.setEncoding('UTF-8');
<!-- 处理流事件 data,end,error -->
readerStream.on('data',function(chunk){//当有数据可读时触发
    data +=chunk;
});
readerStream.on('end',function(){//没有更多数据时触发
    console.log(data);
});
readerStream.on('error',function(err){//在接收和写入发生错误时触发
    console.log(err.stack);
})
console.log('完成，读取数据');


<!-- 写入流 -->
var fs2=require("fs");
var data2="读入文件已经被重写";
//创建一个可以写入的流，写入到文件input.txt中
var writerStream=fs2.createWriteStream('input.txt');
//使用utf-8编码写入数据
writerStream.write(data2,'UTF-8');
//标记文件末尾
writerStream.end();
//处理流事件
writerStream.on('finish',function(){
    console.log('写入完成');
})
console.log("完成，写入数据");


<!-- 管道流 从一个文件中读取写入到另一个文件 -->
var fsGd=require("fs");
<!-- 创建一个可读流 -->
var readerStreamGd=fsGd.createReadStream('input.txt');
<!-- 创建一个可写流 -->
var writerStreamGd=fsGd.createWriteStream('output.txt');
<!-- 管道读写操作 读取input.txt文件内容，并将内容写入到自动生成的output.txt文件中 -->
readerStreamGd.pipe(writerStreamGd);
console.log('完毕，管道');


<!-- 链式流 -->
var fsLs = require("fs");
var zlib = require('zlib');
<!-- 压缩 -->
fsLs.createReadStream('input.txt')
  .pipe(zlib.createGzip())
  .pipe(fsLs.createWriteStream('input.txt.gz'));
console.log("文件压缩完成。");
<!-- 解压 -->
<!-- fsLs2.createReadStream('input.txt.gz') -->
  <!-- .pipe(zlib2.createGunzip()) -->
  <!-- .pipe(fsLs2.createWriteStream('input.txt')); -->
<!-- console.log("文件解压完成。"); -->

