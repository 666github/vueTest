<!-- 路由使用 -->
var server = require("./main_nodeServer");
var router = require("./main_nodeRouter");
server.start(router.route);

<!-- 而 Node.js 中的全局对象是 global，所有全局变量（除了 global 本身以外）都是 global 对象的属性。 -->
<!-- 在最外层定义的变量；全局对象的属性；隐式定义的变量（未定义直接赋值的变量）。 -->
<!-- 注意： 最好不要使用 var 定义变量以避免引入全局变量，因为全局变量会污染命名空间，提高代码的耦合风险。 -->
