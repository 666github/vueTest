module.exports={
    entry:{
        "main":"./src/index.js"
    },
    output:{
        filename:'./dist/main.js'
    },
    module:{
        loaders:{
            
        }
    }
}