var Hello = require('./node模块系统1.js'); 
hello = new Hello(); 
hello.setName('BYVoid'); 
hello.sayHello(); 
<!-- 函数传递 -->
var http = require("http");
function onRequest(request, response) {
  response.writeHead(200, {"Content-Type": "text/plain"});
  response.write("Hello World");
  response.end();
}
http.createServer(onRequest).listen(8888);
<!-- es6类的继承于重写 -->
class Person{
    constructor(nickname, age){
        this.nickname = nickname
        this.age =age
    }
    getNickname(){
        return this.nickname
    }
    getAge(){
        return this.age
    }
    summary(){
        return  'this is Person'
    }
}
class Male extends Person {
summary(){
    return  'this is Male'
}
}
let male=new Male()
console.log(male.summary()) // this is Male
