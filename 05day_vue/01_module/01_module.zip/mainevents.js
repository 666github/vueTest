<!-- 事件循环 -->
<!-- // 引入 events 模块 -->
var events = require('events');
<!-- // 创建 eventEmitter 对象  事件触发与事件监听功能的封装-->
var eventEmitter = new events.EventEmitter();
<!-- // 创建事件处理程序 -->
var connectHandler = function connected() {
   console.log('连接成功。'); 
   <!-- // 触发 data_received 事件  -->
   eventEmitter.emit('data_received');
}
<!-- // 绑定 connection 事件处理程序 -->
eventEmitter.on('connection', connectHandler);
<!-- // 使用匿名函数绑定 data_received 事件 -->
eventEmitter.on('data_received', function(){
   console.log('数据接收成功。');
}); 
<!-- // 触发 connection 事件  -->
eventEmitter.emit('connection');
console.log("程序执行完毕。");

   <!-- 1.引入events模块 -->
   <!-- 2.创建eventEmitter对象 -->
   <!-- 3.创建事件处理程序 -->
   <!-- 4.绑定事件处理程序eventEmitter.on -->
   <!-- 5.触发事件处理程序 eventEmitter.emit -->

 