<!-- 对象间原型继承的函数 -->
var util = require('util'); 
function Base() { 
    this.name = 'base'; 
    this.base = 1991; 
    this.sayHello = function() { 
    console.log('Hello ' + this.name); 
    }; 
} 
Base.prototype.showName = function() { 
    console.log(this.name);
}; 
function Sub() { 
    this.name = 'sub'; 
} 
util.inherits(Sub, Base); //Sub 仅仅继承了Base 在原型中定义的函数，而构造函数内部创造的 base 属 性和 sayHello 函数都没有被 Sub 继承。
var objBase = new Base(); 
objBase.showName(); 
objBase.sayHello(); 
console.log(objBase);

var objSub = new Sub(); 
objSub.showName(); 
console.log(objSub); 

<!-- 将对象转换为字符串-->
<!-- util.inspect(object,[showHidden],[depth],[colors]) 是一个将任意对象转换 为字符串的方法，通常用于调试和错误输出。它至少接受一个参数 object，即要转换的对象。 -->
function Person() { 
    this.name = 'byvoid'; 
    this.toString = function() { //util.inspect 并不会简单地直接把对象转换为字符串，即使该对象定义了toString 方法也不会调用。
    return this.name; 
    }; 
} 
var obj = new Person(); 
console.log(util.inspect(obj)); 
console.log(util.inspect(obj, true)); //true可选参数，输出更多隐藏信息
util.isArray([]);//true
util.isRegExp(object);//参数 "object" 是一个正则表达式返回true，否则返回false。
util.isDate(object);//如果给定的参数 "object" 是一个日期返回true，否则返回false。
util.isError(object);//参数 "object" 是一个错误对象返回true，否则返回false。

